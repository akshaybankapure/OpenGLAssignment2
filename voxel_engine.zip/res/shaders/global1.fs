#version 330 core

in vec4 toColor;
out vec4 FragColor;

void main()
{
    FragColor = toColor;
}
